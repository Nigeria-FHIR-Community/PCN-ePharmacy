# Home - PCN ePharmacy Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://pcn.gov.ng/ImplementationGuide/ePharmacyIG | *Version*:0.1.0 |
| Draft as of 2025-10-13 | *Computable Name*:ePharmacyIG |

# Nigeria ePharmacy FHIR Implementation Guide

This Implementation Guide (IG) defines the **FHIR-based logical and interoperability layer** for the **National ePharmacy Platform**, translating the **Pharmacy Council of Nigeria (PCN)** business and technical requirements into machine-readable artefacts.

It builds directly on the **WHO SMART Guidelines Layer 2 Digital Adaptation Kit (DAK)** methodology and aligns with the following key reference frameworks:

* Nigeria National Prescription and Dispensing Policy (2025)
* Draft Electronic Pharmacy Regulations (2024)
* NIS ISO 17523:2019 – Health Informatics Requirements for Electronic Prescriptions
* FIP/WHO Guidelines on Good Pharmacy Practice (2012)
* NDPA 2023 & FCCPC Consumer Protection Guidelines
* NAFDAC Greenbook and MED Safety APIs

-------

## Background and Purpose

Digital technologies are transforming healthcare. Yet pharmacy services in Nigeria remain fragmented, with manual workflows, poor data visibility, and limited interoperability.
 This IG provides a **standards-based blueprint** for integrating prescription, dispensing, and regulatory oversight systems across the country.

Through FHIR profiles, value sets, extensions, and exchange patterns, the guide supports:

* **ePrescription Generation** by statutory and non-statutory prescribers
* **eDispensing and ADR Monitoring** with regulatory compliance
* **Licensing & Renewal** of ePharmacies through PCN Hub APIs
* **Integration with NHIA, MDCN, NAFDAC, and NIMC Registries**
* **Public dashboards and compliance analytics** for transparency

-------

## Intended Audience

* Pharmacy Council of Nigeria – Regulatory and ICT Departments
* ePharmacy platform developers and aggregators
* Hospital and Community Pharmacy operators
* Prescribers, Pharmacists, and Technicians
* NHIA, MDCN, NAFDAC integration teams
* Standards organizations (SON, NITDA, NDPC)

-------

## ePharmacy Enterprise Architecture

The **PCN Enterprise Architecture** follows a **hub-and-spoke model**: a central **ePharmacy Hub** connects regulatory systems, shared registries, and external ePharmacy platforms via secure APIs. It ensures interoperability among prescribers, pharmacies, insurers, and regulators while enforcing data privacy and traceability.

**(Architecture diagram appears in Component 1 of the Specification.)**

-------

## IG Components

| | | |
| :--- | :--- | :--- |
| **Personas** | Profiles of clients, prescribers, dispensers, inspectors | Component 2 |
| **User Scenarios** | Narrative use cases from registration to delivery & ADR reporting | Component 3 |
| **Business Processes / BPMN** | ePharmacy Registration → Dispensing → Compliance | Component 4 |
| **Core Data Elements** | Data dictionary for prescription, dispensing, billing, ADR | Component 5 |
| **Decision Support Logic** | Rule tables (PD.DT 1-34) governing validation & safety | Component 6 |
| **Indicators & Monitoring** | KPIs for regulatory oversight and service quality | Component 7 |
| **Functional / Non-Functional Reqs** | 74 functional + 69 non-functional specs | Component 8 |
| **UI Mock-ups** | Sample interfaces for regulators and operators | Component 9 |

-------

## Key FHIR Profiles

| | |
| :--- | :--- |
| **Licensing & Facility Registry** | `Organization (PCN License)`•`Location (ePharmacy Premises)` |
| **Prescriber & Dispenser Identity** | `Practitioner`,`PractitionerRole`,`Endpoint (MDCN / PCN)` |
| **ePrescription Workflow** | `Task (Prescription Request)`•`MedicationRequest`•`MedicationDispense` |
| **Payment & Claims** | `Claim`,`ClaimResponse`,`Invoice`,`PaymentNotice`(NHIA integration) |
| **Pharmacovigilance & ADR** | `AdverseEvent`,`Observation`,`DetectedIssue`,`Communication` |
| **Compliance & Inspection** | `Task (Inspection)`,`DocumentReference (Compliance Report)` |
| **Hub Interoperability** | `Bundle (Transaction / Collection)`,`Subscription`,`AuditEvent` |

-------

## Implementation Approach

The IG translation follows these steps:

1. **Map DAK components to FHIR Resources**
(Personas → Practitioner/Patient; Workflows → Task/ActivityDefinition)
1. **Define Profiles and Extensions**
per business rules (e.g.,`NGPrescriptionType`,`NGDispenseChannel`)
1. **Bind CodeSystems and ValueSets**
referencing national terminologies and SNOMED-CT/ATC cross-maps
1. **Generate Examples and Test Bundles**
1. **Publish IG**via FHIR CI Build for stakeholder review
1. **Validate using IHE Gazelle / FHIR Validator**

-------

## Governance and Next Steps

Development is coordinated by **PCN ICT Department** with technical support from **DHIN** under the **SFH ePharmacy4FP Project**, with inputs from NITDA, NAFDAC, NHIA, and SON.
 The next release (v0.2.0) will introduce conformance resources and bundle examples for core transactions (Registration, Prescription, Dispensing, ADR reporting).

-------

© 2025 Pharmacy Council of Nigeria

