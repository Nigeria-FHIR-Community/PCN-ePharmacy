# Home - PCN ePharmacy Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://pcn.gov.ng/ImplementationGuide/ePharmacyIG | *Version*:0.1.0 |
| Draft as of 2025-10-13 | *Computable Name*:ePharmacyIG |

# Nigeria ePharmacy FHIR Implementation Guide

This Implementation Guide (IG) defines the **FHIR-based logical and interoperability layer** for the **National ePharmacy Platform**, translating the **Pharmacy Council of Nigeria (PCN)** business and technical requirements into machine-readable artefacts.

It builds directly on the **WHO SMART Guidelines Layer 2 Digital Adaptation Kit (DAK)** methodology and aligns with the following key reference frameworks:

* Nigeria National Prescription and Dispensing Policy (2025)
* Draft Electronic Pharmacy Regulations (2024)
* NIS ISO 17523:2019 – Health Informatics Requirements for Electronic Prescriptions
* FIP/WHO Guidelines on Good Pharmacy Practice (2012)
* NDPA 2023 & FCCPC Consumer Protection Guidelines
* NAFDAC Greenbook and MED Safety APIs

-------

## Background and Purpose

Digital technologies are transforming healthcare. Yet pharmacy services in Nigeria remain fragmented, with manual workflows, poor data visibility, and limited interoperability.
 This IG provides a **standards-based blueprint** for integrating prescription, dispensing, and regulatory oversight systems across the country.

Through FHIR profiles, value sets, extensions, and exchange patterns, the guide supports:

* **ePrescription Generation** by statutory and non-statutory prescribers
* **eDispensing and ADR Monitoring** with regulatory compliance
* **Licensing & Renewal** of ePharmacies through PCN Hub APIs
* **Integration with NHIA, MDCN, NAFDAC, and NIMC Registries**
* **Public dashboards and compliance analytics** for transparency

-------

## Intended Audience

* Pharmacy Council of Nigeria – Regulatory and ICT Departments
* ePharmacy platform developers and aggregators
* Hospital and Community Pharmacy operators
* Prescribers, Pharmacists, and Technicians
* NHIA, MDCN, NAFDAC integration teams
* Standards organizations (SON, NITDA, NDPC)

-------

## ePharmacy Enterprise Architecture

The **PCN Enterprise Architecture** follows a **hub-and-spoke model**: a central **ePharmacy Hub** connects regulatory systems, shared registries, and external ePharmacy platforms via secure APIs. It ensures interoperability among prescribers, pharmacies, insurers, and regulators while enforcing data privacy and traceability.

**(Architecture diagram appears in Component 1 of the Specification.)**

-------

## IG Components

| | | |
| :--- | :--- | :--- |
| **Personas** | Profiles of clients, prescribers, dispensers, inspectors | Component 2 |
| **User Scenarios** | Narrative use cases from registration to delivery & ADR reporting | Component 3 |
| **Business Processes / BPMN** | ePharmacy Registration → Dispensing → Compliance | Component 4 |
| **Core Data Elements** | Data dictionary for prescription, dispensing, billing, ADR | Component 5 |
| **Decision Support Logic** | Rule tables (PD.DT 1-34) governing validation & safety | Component 6 |
| **Indicators & Monitoring** | KPIs for regulatory oversight and service quality | Component 7 |
| **Functional / Non-Functional Reqs** | 74 functional + 69 non-functional specs | Component 8 |
| **UI Mock-ups** | Sample interfaces for regulators and operators | Component 9 |

-------

## Key FHIR Profiles

| | |
| :--- | :--- |
| **Licensing & Facility Registry** | `Organization (PCN License)`•`Location (ePharmacy Premises)` |
| **Prescriber & Dispenser Identity** | `Practitioner`,`PractitionerRole`,`Endpoint (MDCN / PCN)` |
| **ePrescription Workflow** | `Task (Prescription Request)`•`MedicationRequest`•`MedicationDispense` |
| **Payment & Claims** | `Claim`,`ClaimResponse`,`Invoice`,`PaymentNotice`(NHIA integration) |
| **Pharmacovigilance & ADR** | `AdverseEvent`,`Observation`,`DetectedIssue`,`Communication` |
| **Compliance & Inspection** | `Task (Inspection)`,`DocumentReference (Compliance Report)` |
| **Hub Interoperability** | `Bundle (Transaction / Collection)`,`Subscription`,`AuditEvent` |

-------

## Implementation Approach

The IG translation follows these steps:

1. **Map DAK components to FHIR Resources**
(Personas → Practitioner/Patient; Workflows → Task/ActivityDefinition)
1. **Define Profiles and Extensions**
per business rules (e.g.,`NGPrescriptionType`,`NGDispenseChannel`)
1. **Bind CodeSystems and ValueSets**
referencing national terminologies and SNOMED-CT/ATC cross-maps
1. **Generate Examples and Test Bundles**
1. **Publish IG**via FHIR CI Build for stakeholder review
1. **Validate using IHE Gazelle / FHIR Validator**

-------

## Governance and Next Steps

Development is coordinated by **PCN ICT Department** with technical support from **DHIN** under the **SFH ePharmacy4FP Project**, with inputs from NITDA, NAFDAC, NHIA, and SON.
 The next release (v0.2.0) will introduce conformance resources and bundle examples for core transactions (Registration, Prescription, Dispensing, ADR reporting).

-------

© 2025 Pharmacy Council of Nigeria



## Resource Content

```json
{
  "resourceType" : "ImplementationGuide",
  "id" : "ePharmacyIG",
  "url" : "https://pcn.gov.ng/ImplementationGuide/ePharmacyIG",
  "version" : "0.1.0",
  "name" : "ePharmacyIG",
  "title" : "PCN ePharmacy Implementation Guide",
  "status" : "draft",
  "date" : "2025-10-13T08:31:38+01:00",
  "publisher" : "PCN",
  "contact" : [
    {
      "name" : "PCN",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://pcn.gov.ng"
        },
        {
          "system" : "email",
          "value" : "info@dhin-hie.org"
        }
      ]
    },
    {
      "name" : "Pharmacy Council of Nigeria.",
      "telecom" : [
        {
          "system" : "email",
          "value" : "info@dhin-hie.org",
          "use" : "work"
        }
      ]
    }
  ],
  "description" : "Implementation Guide for PCN's ePharmacy Technical Specification",
  "jurisdiction" : [
    {
      "coding" : [
        {
          "system" : "urn:iso:std:iso:3166",
          "code" : "NG",
          "display" : "Nigeria"
        }
      ]
    }
  ],
  "packageId" : "ePharmacyIG",
  "license" : "CC0-1.0",
  "fhirVersion" : ["4.0.1"],
  "dependsOn" : [
    {
      "id" : "hl7tx",
      "extension" : [
        {
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
          "valueMarkdown" : "Automatically added as a dependency - all IGs depend on HL7 Terminology"
        }
      ],
      "uri" : "http://terminology.hl7.org/ImplementationGuide/hl7.terminology",
      "packageId" : "hl7.terminology.r4",
      "version" : "6.5.0"
    },
    {
      "id" : "hl7ext",
      "extension" : [
        {
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/implementationguide-dependency-comment",
          "valueMarkdown" : "Automatically added as a dependency - all IGs depend on the HL7 Extension Pack"
        }
      ],
      "uri" : "http://hl7.org/fhir/extensions/ImplementationGuide/hl7.fhir.uv.extensions",
      "packageId" : "hl7.fhir.uv.extensions.r4",
      "version" : "5.2.0"
    }
  ],
  "definition" : {
    "extension" : [
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "copyrightyear"
          },
          {
            "url" : "value",
            "valueString" : "2025+"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "releaselabel"
          },
          {
            "url" : "value",
            "valueString" : "draft"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "autoload-resources"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "path-liquid"
          },
          {
            "url" : "value",
            "valueString" : "template/liquid"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "path-liquid"
          },
          {
            "url" : "value",
            "valueString" : "input/liquid"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "path-qa"
          },
          {
            "url" : "value",
            "valueString" : "temp/qa"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "path-temp"
          },
          {
            "url" : "value",
            "valueString" : "temp/pages"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "path-output"
          },
          {
            "url" : "value",
            "valueString" : "output"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "path-suppressed-warnings"
          },
          {
            "url" : "value",
            "valueString" : "input/ignoreWarnings.txt"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "path-history"
          },
          {
            "url" : "value",
            "valueString" : "https://pcn.gov.ng/history.html"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "template-html"
          },
          {
            "url" : "value",
            "valueString" : "template-page.html"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "template-md"
          },
          {
            "url" : "value",
            "valueString" : "template-page-md.html"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "apply-contact"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "apply-context"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "apply-copyright"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "apply-jurisdiction"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "apply-license"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "apply-publisher"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "apply-version"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "apply-wg"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "active-tables"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "fmm-definition"
          },
          {
            "url" : "value",
            "valueString" : "http://hl7.org/fhir/versions.html#maturity"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "propagate-status"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "excludelogbinaryformat"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueString" : "tabbed-snapshots"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-internal-dependency",
        "valueCode" : "hl7.fhir.uv.tools.r4#0.8.0"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "copyrightyear"
          },
          {
            "url" : "value",
            "valueString" : "2025+"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "releaselabel"
          },
          {
            "url" : "value",
            "valueString" : "draft"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "autoload-resources"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "path-liquid"
          },
          {
            "url" : "value",
            "valueString" : "template/liquid"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "path-liquid"
          },
          {
            "url" : "value",
            "valueString" : "input/liquid"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "path-qa"
          },
          {
            "url" : "value",
            "valueString" : "temp/qa"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "path-temp"
          },
          {
            "url" : "value",
            "valueString" : "temp/pages"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "path-output"
          },
          {
            "url" : "value",
            "valueString" : "output"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "path-suppressed-warnings"
          },
          {
            "url" : "value",
            "valueString" : "input/ignoreWarnings.txt"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "path-history"
          },
          {
            "url" : "value",
            "valueString" : "https://pcn.gov.ng/history.html"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "template-html"
          },
          {
            "url" : "value",
            "valueString" : "template-page.html"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "template-md"
          },
          {
            "url" : "value",
            "valueString" : "template-page-md.html"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "apply-contact"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "apply-context"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "apply-copyright"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "apply-jurisdiction"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "apply-license"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "apply-publisher"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "apply-version"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "apply-wg"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "active-tables"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "fmm-definition"
          },
          {
            "url" : "value",
            "valueString" : "http://hl7.org/fhir/versions.html#maturity"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "propagate-status"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "excludelogbinaryformat"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      },
      {
        "extension" : [
          {
            "url" : "code",
            "valueCode" : "tabbed-snapshots"
          },
          {
            "url" : "value",
            "valueString" : "true"
          }
        ],
        "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-parameter"
      }
    ],
    "resource" : [
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/ng-coverage-enquiry-bundle"
        },
        "name" : "1-NG Bundle Coverage Enquiry",
        "description" : "A FHIR bundle used by a patient or provider to inquire about health insurance coverage from a payer or insurer.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/ng-dispense-notification-bundle"
        },
        "name" : "2-NG Bundle Dispense Notification",
        "description" : "A FHIR bundle used by a pharmacy to notify the prescriber or health authority of a medication dispense event.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/ng-prescription-bundle"
        },
        "name" : "3-NG Bundle Prescription",
        "description" : "A FHIR bundle for sharing an electronic prescription between a prescriber and a pharmacy.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Medication"
          }
        ],
        "reference" : {
          "reference" : "Medication/medication-001"
        },
        "name" : "Example: Amoxicillin 250mg Capsule",
        "description" : "An example medication definition for Amoxicillin.",
        "exampleCanonical" : "https://pcn.gov.ng/StructureDefinition/ng-medication"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "AuditEvent"
          }
        ],
        "reference" : {
          "reference" : "AuditEvent/audit-001"
        },
        "name" : "Example: AuditEvent for Prescription Access",
        "description" : "An example AuditEvent recording a practitioner viewing a prescription.",
        "exampleCanonical" : "https://pcn.gov.ng/StructureDefinition/ng-audit-event"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Coverage"
          }
        ],
        "reference" : {
          "reference" : "Coverage/coverage-001"
        },
        "name" : "Example: Claim Coverage",
        "description" : "An example of a patient's insurance coverage details.",
        "exampleCanonical" : "https://pcn.gov.ng/StructureDefinition/ng-claim-coverage"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Communication"
          }
        ],
        "reference" : {
          "reference" : "Communication/example-communication"
        },
        "name" : "Example: Communication from Pharmacy to Prescriber",
        "description" : "An example communication sent from a pharmacist to a doctor requesting clarification on a prescription.",
        "exampleCanonical" : "https://pcn.gov.ng/StructureDefinition/ng-communication"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Condition"
          }
        ],
        "reference" : {
          "reference" : "Condition/condition-001"
        },
        "name" : "Example: Condition for Prescription",
        "description" : "An example diagnosis of Otitis media related to a prescription.",
        "exampleCanonical" : "https://pcn.gov.ng/StructureDefinition/ng-condition"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "CoverageEligibilityRequest"
          }
        ],
        "reference" : {
          "reference" : "CoverageEligibilityRequest/eligibility-request-001"
        },
        "name" : "Example: Coverage Eligibility Request",
        "description" : "An example of a patient's request to check insurance service eligibility.",
        "exampleCanonical" : "https://pcn.gov.ng/StructureDefinition/ng-eligibility-request"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "MedicationDispense"
          }
        ],
        "reference" : {
          "reference" : "MedicationDispense/dispense-001"
        },
        "name" : "Example: Medication Dispense",
        "description" : "An example of a pharmacist dispensing Amoxicillin 250mg.",
        "exampleCanonical" : "https://pcn.gov.ng/StructureDefinition/ng-medication-dispense"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "MedicationRequest"
          }
        ],
        "reference" : {
          "reference" : "MedicationRequest/medicationrequest-001"
        },
        "name" : "Example: MedicationRequest",
        "description" : "An example of an electronic prescription for Amoxicillin.",
        "exampleCanonical" : "https://pcn.gov.ng/StructureDefinition/ng-medication-request"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Organization"
          }
        ],
        "reference" : {
          "reference" : "Organization/organization-001"
        },
        "name" : "Example: NG Organization",
        "description" : "An example of a healthcare facility organization.",
        "exampleCanonical" : "https://pcn.gov.ng/StructureDefinition/ng-imm-organization"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Patient"
          }
        ],
        "reference" : {
          "reference" : "Patient/patient-001"
        },
        "name" : "Example: NG Patient",
        "description" : "An example instance of a Nigerian patient profile",
        "exampleCanonical" : "https://pcn.gov.ng/StructureDefinition/NgPatient"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Practitioner"
          }
        ],
        "reference" : {
          "reference" : "Practitioner/practitioner-001"
        },
        "name" : "Example: NG Practitioner",
        "description" : "An example of a Nigerian healthcare practitioner.",
        "exampleCanonical" : "https://pcn.gov.ng/StructureDefinition/NgPractitioner"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "PractitionerRole"
          }
        ],
        "reference" : {
          "reference" : "PractitionerRole/practitioner-role-001"
        },
        "name" : "Example: NG PractitionerRole",
        "description" : "An example defining the role of a practitioner within a Nigerian healthcare organization.",
        "exampleCanonical" : "https://pcn.gov.ng/StructureDefinition/ng-practitionerrole"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Location"
          }
        ],
        "reference" : {
          "reference" : "Location/example-location"
        },
        "name" : "Example: Pharmacy Location",
        "description" : "An example location representing a pharmacy branch.",
        "exampleCanonical" : "https://pcn.gov.ng/StructureDefinition/ng-location"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Encounter"
          }
        ],
        "reference" : {
          "reference" : "Encounter/encounter-001"
        },
        "name" : "Example: Prescription Encounter",
        "description" : "An example encounter related to an ePrescription event.",
        "exampleCanonical" : "https://pcn.gov.ng/StructureDefinition/ng-prescription-encounter"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Provenance"
          }
        ],
        "reference" : {
          "reference" : "Provenance/provenance-001"
        },
        "name" : "Example: Provenance of ePrescription",
        "description" : "An example of provenance capturing the author and timestamp of a prescription.",
        "exampleCanonical" : "https://pcn.gov.ng/StructureDefinition/ng-provenance"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "DocumentReference"
          }
        ],
        "reference" : {
          "reference" : "DocumentReference/example-document-reference"
        },
        "name" : "Example: Scanned Discharge Summary",
        "description" : "An example of a scanned discharge summary document reference.",
        "exampleCanonical" : "https://pcn.gov.ng/StructureDefinition/ng-document-reference"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "Task"
          }
        ],
        "reference" : {
          "reference" : "Task/example-claim-task"
        },
        "name" : "Example: Task for Dispensing Prescription",
        "description" : "A task representing the assignment to dispense a prescription in an ePrescription workflow.",
        "exampleCanonical" : "https://pcn.gov.ng/StructureDefinition/ng-claim-task"
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/ng-audit-event"
        },
        "name" : "NG AuditEvent",
        "description" : "A profile for logging access and interactions with health data in Nigeria, such as prescriptions or patient records.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/ng-communication"
        },
        "name" : "NG Communication",
        "description" : "A profile for recording formal communication exchanges such as notifications, clarifications, or feedback in health service delivery.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/ng-condition"
        },
        "name" : "NG Condition",
        "description" : "A profile representing the diagnosis or reason for prescribing medication in Nigeria.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/ng-document-reference"
        },
        "name" : "NG DocumentReference",
        "description" : "A profile for referencing external or internal documents such as lab reports, discharge summaries, prescriptions, or scanned forms.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:complex-type"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/ng-dosage"
        },
        "name" : "NG Dosage",
        "description" : "A profile for dosage instructions in ePrescriptions.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/ng-prescription-encounter"
        },
        "name" : "NG Encounter",
        "description" : "A profile representing patient encounters related to ePrescription.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/ng-location"
        },
        "name" : "NG Location",
        "description" : "A profile representing facility locations such as pharmacies, wards, or service points in Nigeria.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/ng-medication"
        },
        "name" : "NG Medication",
        "description" : "A profile for medications prescribed and dispensed in Nigeria.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/ng-medication-dispense"
        },
        "name" : "NG MedicationDispense",
        "description" : "A profile for recording dispensation of prescribed medications by a pharmacy in Nigeria.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/ng-medication-request"
        },
        "name" : "NG MedicationRequest",
        "description" : "A profile for electronic prescriptions issued by Nigerian healthcare providers.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/ng-imm-organization"
        },
        "name" : "NG Organization",
        "description" : "An organization profile representing healthcare facilities responsible for health services or other types of organizations.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/NgPatient"
        },
        "name" : "NG Patient",
        "description" : "Nigeria Patient Profile",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/NgPractitioner"
        },
        "name" : "NG Practitioner",
        "description" : "Profile for a Nigerian Practitioner",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/ng-practitionerrole"
        },
        "name" : "NG PractitionerRole",
        "description" : "A profile for defining the role of a practitioner within an organization.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/ng-provenance"
        },
        "name" : "NG Provenance",
        "description" : "A profile for capturing metadata about creation or modification of health data in Nigeria, especially for audit and signature purposes.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/ng-claim-task"
        },
        "name" : "NG Task",
        "description" : "A profile for workflow and task management in ePrescription processing.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/ng-claim-coverage"
        },
        "name" : "NG-Claim Coverage",
        "description" : "A profile capturing a patient's insurance coverage details.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "StructureDefinition:resource"
          }
        ],
        "reference" : {
          "reference" : "StructureDefinition/ng-eligibility-request"
        },
        "name" : "NG-CoverageEligibilityRequest",
        "description" : "A profile for checking patient's eligibility for insurance services.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "CodeSystem"
          }
        ],
        "reference" : {
          "reference" : "CodeSystem/nigeria-wards"
        },
        "name" : "NG-Imm Administrative Wards CS",
        "description" : "This CodeSystem defines ward codes and names mapped to their respective Local Government Areas (LGAs) in Nigeria.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "CodeSystem"
          }
        ],
        "reference" : {
          "reference" : "CodeSystem/nigeria-facility-type"
        },
        "name" : "NG-Imm Facility Type CS",
        "description" : "A standardized classification system used to describe the type or level of health facility within a healthcare delivery system, based on the scope of services provided, staffing, infrastructure, and administrative role.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "CodeSystem"
          }
        ],
        "reference" : {
          "reference" : "CodeSystem/nigeria-gender"
        },
        "name" : "NG-Imm Gender CS",
        "description" : "The administrative gender of a person.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/nigeria-gender"
        },
        "name" : "NG-Imm Gender or Sex VS",
        "description" : "Subset of HL7 administrative-gender limited to 'male' and 'female'.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/nigeria-facility-types"
        },
        "name" : "NG-Imm HealthFacility Type VS",
        "description" : "Classification of Nigerian health facilities",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/nigeria-languages"
        },
        "name" : "NG-Imm Languages VS",
        "description" : "The Patient's preferred language for communication.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "CodeSystem"
          }
        ],
        "reference" : {
          "reference" : "CodeSystem/nigeria-lgas"
        },
        "name" : "NG-Imm LGAs in Nigeria CS",
        "description" : "This CodeSystem defines LGA codes and names mapped to their respective States in Nigeria.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/nigeria-lgas"
        },
        "name" : "NG-Imm LGAs VS",
        "description" : "The administrative Local Government Areas where a person or a facility is.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/nigeria-location-owner"
        },
        "name" : "NG-Imm Location Owner",
        "description" : "The owner of an Immunization location",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "CodeSystem"
          }
        ],
        "reference" : {
          "reference" : "CodeSystem/nigeria-location-owner-cs"
        },
        "name" : "NG-Imm Location Owner CS",
        "description" : "This CodeSystem defines Immunization Location Owner.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "CodeSystem"
          }
        ],
        "reference" : {
          "reference" : "CodeSystem/nigeria-states"
        },
        "name" : "NG-Imm States in Nigeria CS",
        "description" : "This CodeSystem defines ward codes and names mapped to their respective States in Nigeria.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/nigeria-states"
        },
        "name" : "NG-Imm States VS",
        "description" : "The state where a person or a facility is.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "ValueSet"
          }
        ],
        "reference" : {
          "reference" : "ValueSet/nigeria-wards"
        },
        "name" : "NG-Imm Wards VS",
        "description" : "The administrative Ward (within an LGA) where a person or a facility is.",
        "exampleBoolean" : false
      },
      {
        "extension" : [
          {
            "url" : "http://hl7.org/fhir/tools/StructureDefinition/resource-information",
            "valueString" : "CodeSystem"
          }
        ],
        "reference" : {
          "reference" : "CodeSystem/nigeria-languages"
        },
        "name" : "NG‑Imm Languages in Nigeria CS",
        "description" : "This CodeSystem defines codes for major languages spoken across Nigeria.",
        "exampleBoolean" : false
      }
    ],
    "page" : {
      "extension" : [
        {
          "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
          "valueUrl" : "toc.html"
        }
      ],
      "nameUrl" : "toc.html",
      "title" : "Table of Contents",
      "generation" : "html",
      "page" : [
        {
          "extension" : [
            {
              "url" : "http://hl7.org/fhir/tools/StructureDefinition/ig-page-name",
              "valueUrl" : "index.html"
            }
          ],
          "nameUrl" : "index.html",
          "title" : "Home",
          "generation" : "markdown"
        }
      ]
    },
    "parameter" : [
      {
        "code" : "path-resource",
        "value" : "input/capabilities"
      },
      {
        "code" : "path-resource",
        "value" : "input/examples"
      },
      {
        "code" : "path-resource",
        "value" : "input/extensions"
      },
      {
        "code" : "path-resource",
        "value" : "input/models"
      },
      {
        "code" : "path-resource",
        "value" : "input/operations"
      },
      {
        "code" : "path-resource",
        "value" : "input/profiles"
      },
      {
        "code" : "path-resource",
        "value" : "input/resources"
      },
      {
        "code" : "path-resource",
        "value" : "input/vocabulary"
      },
      {
        "code" : "path-resource",
        "value" : "input/maps"
      },
      {
        "code" : "path-resource",
        "value" : "input/testing"
      },
      {
        "code" : "path-resource",
        "value" : "input/history"
      },
      {
        "code" : "path-resource",
        "value" : "fsh-generated/resources"
      },
      {
        "code" : "path-pages",
        "value" : "template/config"
      },
      {
        "code" : "path-pages",
        "value" : "input/images"
      },
      {
        "code" : "path-tx-cache",
        "value" : "input-cache/txcache"
      }
    ]
  }
}

```
